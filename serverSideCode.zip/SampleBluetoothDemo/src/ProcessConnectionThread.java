import javax.microedition.io.StreamConnection;
import java.awt.*;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.InputStream;


public class ProcessConnectionThread implements Runnable {

    public static final int VOL_UP = 1;
    public static final int VOL_DOWN = 2;
    public static final int MOUSE_MOVE_UP = 3;
    public static final int MOUSE_MOVE_DOWN = 4;
    public static final int MOUSE_MOVE_LEFT = 5;
    public static final int MOUSE_MOVE_RIGHT = 6;
    public static final int MOUSE_CLICK = 7;
    public static final int MOUSE_RIGHT_CLICK = 8;
    public static final int NEXT_BTN = 9;
    public static final int PREV_BTN = 10;
    public static final int UP_BTN = 11;
    public static final int DOWN_BTN = 12;
    public static final int PAGE_UP = 13;
    public static final int PAGE_DOWN = 14;
    public static final int CHANGE_TAB_PREV = 15;
    public static final int CHANGE_TAB_NEXT = 16;
    public static final int ESCAPE_BUTTON = 17;


    // Constant that indicate command from devices
    private static final int EXIT_CMD = -1;
    private StreamConnection mConnection;

    public ProcessConnectionThread(StreamConnection connection) {
        mConnection = connection;
    }

    @Override
    public void run() {
        try {
            // prepare to receive data
            InputStream inputStream = mConnection.openInputStream();

            System.out.println("waiting for input");

            while (true) {
                int command = inputStream.read();

                if (command == EXIT_CMD) {
                    System.out.println("finish process");
                    break;
                }

                processCommand(command);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Process the command from client
     *
     * @param command the command code
     */
    private void processCommand(int command) {
        try {
            Robot robot = new Robot();
            switch (command) {
                case NEXT_BTN:
                    robot.keyPress(KeyEvent.VK_RIGHT);
                    robot.keyRelease(KeyEvent.VK_RIGHT);
                    System.out.println("Right");
                    break;
                case PREV_BTN:
                    robot.keyPress(KeyEvent.VK_LEFT);
                    robot.keyRelease(KeyEvent.VK_LEFT);
                    System.out.println("Left");
                    break;
                case UP_BTN:
                    robot.keyPress(KeyEvent.VK_UP);
                    robot.keyRelease(KeyEvent.VK_UP);
                    System.out.println("Up");
                    break;
                case DOWN_BTN:
                    robot.keyPress(KeyEvent.VK_DOWN);
                    robot.keyRelease(KeyEvent.VK_DOWN);
                    System.out.println("Down");
                    break;
                case PAGE_UP:
                    robot.keyPress(KeyEvent.VK_PAGE_UP);
                    robot.keyRelease(KeyEvent.VK_PAGE_UP);
                    System.out.println("Page Up");
                    break;
                case PAGE_DOWN:
                    robot.keyPress(KeyEvent.VK_PAGE_DOWN);
                    robot.keyRelease(KeyEvent.VK_PAGE_DOWN);
                    System.out.println("Page Down");
                    break;
                case MOUSE_MOVE_UP:
                    PointerInfo pointerInfo = MouseInfo.getPointerInfo();
                    Point pointerInfoLocation = pointerInfo.getLocation();
                    int x = (int) pointerInfoLocation.getX();
                    int y = (int) pointerInfoLocation.getY();
                    System.out.println("Up Moving");
                    robot.mouseMove(x, y - 10);
                    break;
                case MOUSE_MOVE_DOWN:
                    pointerInfo = MouseInfo.getPointerInfo();
                    pointerInfoLocation = pointerInfo.getLocation();
                    x = (int) pointerInfoLocation.getX();
                    y = (int) pointerInfoLocation.getY();
                    System.out.println("Down Moving");
                    robot.mouseMove(x, y + 10);
                    break;
                case MOUSE_MOVE_LEFT:
                    pointerInfo = MouseInfo.getPointerInfo();
                    pointerInfoLocation = pointerInfo.getLocation();
                    x = (int) pointerInfoLocation.getX();
                    y = (int) pointerInfoLocation.getY();
                    System.out.println("left Moving");
                    robot.mouseMove(x - 10, y);
                    break;
                case MOUSE_MOVE_RIGHT:
                    pointerInfo = MouseInfo.getPointerInfo();
                    pointerInfoLocation = pointerInfo.getLocation();
                    x = (int) pointerInfoLocation.getX();
                    y = (int) pointerInfoLocation.getY();
                    System.out.println("Right Moving");
                    robot.mouseMove(x + 10, y);
                    break;
                case MOUSE_CLICK:
                    pointerInfo = MouseInfo.getPointerInfo();
                    pointerInfoLocation = pointerInfo.getLocation();
                    x = (int) pointerInfoLocation.getX();
                    y = (int) pointerInfoLocation.getY();
                    robot.mouseMove(x, y);
                    robot.mousePress(InputEvent.BUTTON1_MASK);
                    robot.mouseRelease(InputEvent.BUTTON1_MASK);
                    System.out.println("Click");
                    break;
                case MOUSE_RIGHT_CLICK:
                    pointerInfo = MouseInfo.getPointerInfo();
                    pointerInfoLocation = pointerInfo.getLocation();
                    x = (int) pointerInfoLocation.getX();
                    y = (int) pointerInfoLocation.getY();
                    robot.mouseMove(x, y);
                    robot.mousePress(InputEvent.BUTTON3_DOWN_MASK);
                    robot.mouseRelease(InputEvent.BUTTON3_DOWN_MASK);
                    System.out.println("Click");
                    break;
                case CHANGE_TAB_PREV:
                    robot.keyPress(KeyEvent.VK_CONTROL);
                    robot.keyPress(KeyEvent.VK_PAGE_UP);
                    robot.keyRelease(KeyEvent.VK_PAGE_UP);
                    robot.keyRelease(KeyEvent.VK_CONTROL);
                    System.out.println("Tab Change ctrl + pageUP");
                    break;
                case CHANGE_TAB_NEXT:
                    robot.keyPress(KeyEvent.VK_CONTROL);
                    robot.keyPress(KeyEvent.VK_PAGE_DOWN);
                    robot.keyRelease(KeyEvent.VK_PAGE_DOWN);
                    robot.keyRelease(KeyEvent.VK_CONTROL);
                    System.out.println("Tab Change ctrl + pageUP");
                    break;
                case ESCAPE_BUTTON:
                    robot.keyPress(KeyEvent.VK_ESCAPE);
                    robot.keyRelease(KeyEvent.VK_ESCAPE);
                    System.out.println("Escape");
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}